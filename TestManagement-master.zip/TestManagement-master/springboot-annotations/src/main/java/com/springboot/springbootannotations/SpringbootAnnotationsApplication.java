package com.springboot.springbootannotations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootAnnotationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootAnnotationsApplication.class, args);
	}

}
